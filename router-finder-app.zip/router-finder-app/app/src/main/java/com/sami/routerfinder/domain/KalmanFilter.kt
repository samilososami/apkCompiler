package com.sami.routerfinder.domain

class KalmanFilter(
    private var q: Double = 0.125,
    private var r: Double = 8.0,
    initialEstimate: Double = -80.0,
    initialError: Double = 1.0
) {
    private var estimate = initialEstimate
    private var error = initialError

    fun reset(value: Double = estimate) {
        estimate = value
        error = 1.0
    }

    fun update(measurement: Double): Double {
        error += q
        val kalmanGain = error / (error + r)
        estimate += kalmanGain * (measurement - estimate)
        error *= (1 - kalmanGain)
        return estimate
    }

    fun value(): Double = estimate
}
