package com.sami.routerfinder.domain

import kotlin.math.abs
import kotlin.math.pow

object RouterEstimator {
    fun estimateDistanceMeters(rssi: Double, txPower: Int = -45, n: Double = 3.0): Double {
        val exponent = (txPower - rssi) / (10 * n)
        return 10.0.pow(exponent).coerceIn(0.5, 30.0)
    }

    fun estimateBearingFromSweep(samples: List<Pair<Float, Double>>): Float {
        if (samples.isEmpty()) return 0f
        return samples.maxByOrNull { it.second }?.first ?: 0f
    }

    fun confidence(samples: List<Pair<Float, Double>>): Float {
        if (samples.size < 5) return 0.15f
        val sorted = samples.map { it.second }.sortedDescending()
        val delta = (sorted.firstOrNull() ?: 0.0) - (sorted.getOrNull(4) ?: 0.0)
        return (abs(delta) / 12.0).toFloat().coerceIn(0.15f, 0.98f)
    }
}
