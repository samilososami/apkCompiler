package com.sami.routerfinder.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.sami.routerfinder.data.WifiNetwork
import com.sami.routerfinder.domain.KalmanFilter
import com.sami.routerfinder.domain.RouterEstimator
import com.sami.routerfinder.service.SensorFusionManager
import com.sami.routerfinder.service.WifiScanner
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class RouterFinderViewModel(
    private val wifiScanner: WifiScanner,
    private val sensorFusionManager: SensorFusionManager
) : ViewModel() {

    enum class Stage { Scan, IdleCalibration, WalkCalibration, SweepCalibration, Guidance }

    data class UiState(
        val stage: Stage = Stage.Scan,
        val networks: List<WifiNetwork> = emptyList(),
        val selectedNetwork: WifiNetwork? = null,
        val status: String = "Escanea y elige una red",
        val filteredRssi: Double = -80.0,
        val headingDeg: Float = 0f,
        val targetBearingDeg: Float = 0f,
        val targetDistanceMeters: Double = 0.0,
        val confidence: Float = 0.2f,
        val stepsDetected: Int = 0,
        val sweepProgress: Float = 0f,
        val sweepSpeedDegPerSec: Float = 0f,
        val sweepSamples: Int = 0
    )

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private val kalman = KalmanFilter()
    private var pollingJob: Job? = null
    private var lastHeading = 0f
    private var accumulatedSweep = 0f
    private val sweepSamples = mutableListOf<Pair<Float, Double>>()
    private var selectedBssid: String? = null

    init {
        refreshNetworks()
    }

    fun refreshNetworks() {
        wifiScanner.start { list ->
            _uiState.value = _uiState.value.copy(networks = list)
        }
    }

    fun selectNetwork(network: WifiNetwork) {
        selectedBssid = network.bssid
        kalman.reset(network.rssi.toDouble())
        sweepSamples.clear()
        accumulatedSweep = 0f
        lastHeading = 0f
        _uiState.value = _uiState.value.copy(
            selectedNetwork = network,
            stage = Stage.IdleCalibration,
            status = "Quédate quieto unos segundos para calibrar"
        )
        startTracking()
        runIdleCalibration()
    }

    private fun startTracking() {
        pollingJob?.cancel()
        sensorFusionManager.stop()
        sensorFusionManager.start { snapshot ->
            val prevHeading = _uiState.value.headingDeg
            val delta = angularDelta(prevHeading, snapshot.headingDeg)
            if (_uiState.value.stage == Stage.SweepCalibration) {
                accumulatedSweep += kotlin.math.abs(delta)
                sweepSamples += snapshot.headingDeg to _uiState.value.filteredRssi
            }

            val nextSteps = if (_uiState.value.stage == Stage.WalkCalibration && snapshot.stepLikeMotion) {
                _uiState.value.stepsDetected + 1
            } else {
                _uiState.value.stepsDetected
            }

            _uiState.value = _uiState.value.copy(
                headingDeg = snapshot.headingDeg,
                sweepSpeedDegPerSec = kotlin.math.abs(snapshot.angularSpeedDeg),
                stepsDetected = nextSteps,
                sweepProgress = (accumulatedSweep / 360f).coerceIn(0f, 1f),
                sweepSamples = sweepSamples.size
            )
        }

        pollingJob = viewModelScope.launch {
            while (true) {
                val rssi = selectedBssid?.let { wifiScanner.latestRssiFor(it) }
                if (rssi != null) {
                    val filtered = kalman.update(rssi.toDouble())
                    val dist = RouterEstimator.estimateDistanceMeters(filtered)
                    _uiState.value = _uiState.value.copy(filteredRssi = filtered, targetDistanceMeters = dist)
                }
                delay(900)
            }
        }
    }

    private fun runIdleCalibration() {
        viewModelScope.launch {
            delay(5000)
            _uiState.value = _uiState.value.copy(
                stage = Stage.WalkCalibration,
                status = "Camina unos pasos en línea recta"
            )
            waitForWalkCompletion()
        }
    }

    private fun waitForWalkCompletion() {
        viewModelScope.launch {
            while (_uiState.value.stepsDetected < 6) {
                delay(250)
            }
            _uiState.value = _uiState.value.copy(
                stage = Stage.SweepCalibration,
                status = "Ahora gira 360° lentamente. Sigue la velocidad ideal y completa la vuelta."
            )
            waitForSweepCompletion()
        }
    }

    private fun waitForSweepCompletion() {
        viewModelScope.launch {
            while (_uiState.value.sweepProgress < 0.98f) {
                delay(200)
            }
            val bearing = RouterEstimator.estimateBearingFromSweep(sweepSamples)
            val confidence = RouterEstimator.confidence(sweepSamples)
            _uiState.value = _uiState.value.copy(
                stage = Stage.Guidance,
                status = "Análisis completado. Sigue la flecha.",
                targetBearingDeg = bearing,
                confidence = confidence
            )
        }
    }

    private fun angularDelta(from: Float, to: Float): Float {
        var delta = to - from
        while (delta > 180f) delta -= 360f
        while (delta < -180f) delta += 360f
        return delta
    }

    override fun onCleared() {
        wifiScanner.stop()
        sensorFusionManager.stop()
        pollingJob?.cancel()
        super.onCleared()
    }

    companion object {
        fun Factory(context: Context): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return RouterFinderViewModel(
                    wifiScanner = WifiScanner(context),
                    sensorFusionManager = SensorFusionManager(context)
                ) as T
            }
        }
    }
}
