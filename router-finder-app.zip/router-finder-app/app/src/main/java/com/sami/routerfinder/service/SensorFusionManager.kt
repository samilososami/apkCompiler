package com.sami.routerfinder.service

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.sqrt

class SensorFusionManager(context: Context) : SensorEventListener {
    data class Snapshot(
        val headingDeg: Float,
        val angularSpeedDeg: Float,
        val linearMagnitude: Float,
        val stepLikeMotion: Boolean
    )

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val gyro = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    private val rotation = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val linearAcceleration = sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)

    private var listener: ((Snapshot) -> Unit)? = null
    private var headingDeg: Float = 0f
    private var angularSpeedDeg: Float = 0f
    private var linearMagnitude: Float = 0f

    fun start(onUpdate: (Snapshot) -> Unit) {
        listener = onUpdate
        gyro?.also { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        rotation?.also { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        linearAcceleration?.also { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    fun stop() {
        listener = null
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_GYROSCOPE -> {
                angularSpeedDeg = Math.toDegrees(event.values[2].toDouble()).toFloat()
            }
            Sensor.TYPE_ROTATION_VECTOR -> {
                val rotationMatrix = FloatArray(9)
                SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                val orientation = FloatArray(3)
                SensorManager.getOrientation(rotationMatrix, orientation)
                headingDeg = ((Math.toDegrees(orientation[0].toDouble()) + 360.0) % 360.0).toFloat()
            }
            Sensor.TYPE_LINEAR_ACCELERATION -> {
                linearMagnitude = sqrt(
                    event.values[0] * event.values[0] +
                        event.values[1] * event.values[1] +
                        event.values[2] * event.values[2]
                )
            }
        }
        listener?.invoke(
            Snapshot(
                headingDeg = headingDeg,
                angularSpeedDeg = angularSpeedDeg,
                linearMagnitude = linearMagnitude,
                stepLikeMotion = linearMagnitude > 1.15f
            )
        )
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}
