package com.sami.routerfinder.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import androidx.core.content.ContextCompat
import com.sami.routerfinder.data.WifiNetwork

class WifiScanner(private val context: Context) {
    private val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private var receiver: BroadcastReceiver? = null

    fun start(onResults: (List<WifiNetwork>) -> Unit) {
        stop()
        receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                val networks = wifiManager.scanResults
                    .orEmpty()
                    .filter { it.SSID.isNotBlank() }
                    .distinctBy { it.BSSID }
                    .sortedByDescending { it.level }
                    .map { it.toNetwork() }
                onResults(networks)
            }
        }
        ContextCompat.registerReceiver(
            context,
            receiver,
            IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        wifiManager.startScan()
    }

    fun stop() {
        receiver?.let {
            runCatching { context.unregisterReceiver(it) }
        }
        receiver = null
    }

    fun latestRssiFor(bssid: String): Int? {
        return wifiManager.scanResults.orEmpty().firstOrNull { it.BSSID == bssid }?.level
    }

    private fun ScanResult.toNetwork(): WifiNetwork {
        val label = when {
            level >= -50 -> "Muy fuerte"
            level >= -60 -> "Fuerte"
            level >= -70 -> "Media"
            else -> "Débil"
        }
        return WifiNetwork(
            ssid = SSID,
            bssid = BSSID,
            rssi = level,
            frequency = frequency,
            levelLabel = label
        )
    }
}
