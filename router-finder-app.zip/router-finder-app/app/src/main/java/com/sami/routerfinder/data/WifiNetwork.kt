package com.sami.routerfinder.data

data class WifiNetwork(
    val ssid: String,
    val bssid: String,
    val rssi: Int,
    val frequency: Int,
    val levelLabel: String
)
