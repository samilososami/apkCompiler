package com.sami.routerfinder.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sami.routerfinder.data.WifiNetwork

@Composable
fun RouterFinderApp(viewModel: RouterFinderViewModel) {
    val state by viewModel.uiState.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF09111F), Color(0xFF111B2E), Color(0xFF18263D))
                )
            )
            .padding(20.dp)
    ) {
        when (state.stage) {
            RouterFinderViewModel.Stage.Scan -> ScanScreen(
                networks = state.networks,
                onRefresh = viewModel::refreshNetworks,
                onSelect = viewModel::selectNetwork
            )
            else -> CalibrationAndGuidanceScreen(state)
        }
    }
}

@Composable
private fun ScanScreen(
    networks: List<WifiNetwork>,
    onRefresh: () -> Unit,
    onSelect: (WifiNetwork) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text(
            "Router Finder",
            style = MaterialTheme.typography.headlineMedium,
            color = Color.White,
            fontWeight = FontWeight.Bold
        )
        Text("Selecciona la red que quieres localizar físicamente.", color = Color(0xFFC4D4F2))
        Button(onClick = onRefresh) { Text("Actualizar") }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(networks) { network ->
                Card(
                    onClick = { onSelect(network) },
                    colors = CardDefaults.cardColors(containerColor = Color(0x1AFFFFFF)),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(network.ssid, color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(network.bssid, color = Color(0xFF98A9CA))
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("${network.rssi} dBm", color = Color(0xFFD7E3FF))
                            Text(network.levelLabel, color = Color(0xFF7DE1C3))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CalibrationAndGuidanceScreen(state: RouterFinderViewModel.UiState) {
    Column(
        verticalArrangement = Arrangement.spacedBy(18.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        Text(
            state.selectedNetwork?.ssid ?: "Red",
            style = MaterialTheme.typography.headlineMedium,
            color = Color.White,
            fontWeight = FontWeight.Bold
        )
        Text(state.status, color = Color(0xFFD3E3FF))

        StatusCard(title = "Señal filtrada", value = "${state.filteredRssi.toInt()} dBm")

        when (state.stage) {
            RouterFinderViewModel.Stage.IdleCalibration -> {
                ProgressCard("Calibrando base", "Quédate quieto mientras limpiamos el ruido de la señal.", 0.5f)
            }
            RouterFinderViewModel.Stage.WalkCalibration -> {
                ProgressCard(
                    "Movimiento",
                    "Da pasos suaves en línea recta.",
                    (state.stepsDetected / 6f).coerceIn(0f, 1f)
                )
            }
            RouterFinderViewModel.Stage.SweepCalibration -> {
                SweepCard(progress = state.sweepProgress, speedDegPerSec = state.sweepSpeedDegPerSec)
            }
            RouterFinderViewModel.Stage.Guidance -> {
                GuidanceCard(state)
            }
            else -> Unit
        }
    }
}

@Composable
private fun StatusCard(title: String, value: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0x14FFFFFF)),
        shape = RoundedCornerShape(28.dp)
    ) {
        Column(Modifier.padding(20.dp)) {
            Text(title, color = Color(0xFF97AACE))
            Spacer(Modifier.height(6.dp))
            Text(
                value,
                color = Color.White,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun ProgressCard(title: String, subtitle: String, progress: Float) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0x14FFFFFF)),
        shape = RoundedCornerShape(28.dp)
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Color(0xFF9CB0D2))
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun SweepCard(progress: Float, speedDegPerSec: Float) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0x14FFFFFF)),
        shape = RoundedCornerShape(28.dp)
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Text("Giro 360°", color = Color.White, fontWeight = FontWeight.Bold)
            Text(
                "Gira lentamente. La app te muestra el progreso y la velocidad en tiempo real.",
                color = Color(0xFF9CB0D2)
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                CircularProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.size(78.dp),
                    strokeWidth = 8.dp
                )
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Progreso: ${(progress * 100).toInt()}%", color = Color.White)
                    Text("Velocidad: ${speedDegPerSec.toInt()} °/s", color = speedColor(speedDegPerSec))
                    Text(
                        when {
                            speedDegPerSec < 18f -> "Un poco más rápido"
                            speedDegPerSec > 60f -> "Más despacio"
                            else -> "Velocidad ideal"
                        },
                        color = Color(0xFF7DE1C3)
                    )
                }
            }
        }
    }
}

@Composable
private fun GuidanceCard(state: RouterFinderViewModel.UiState) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0x14FFFFFF)),
        shape = RoundedCornerShape(30.dp)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(220.dp)
                    .clip(CircleShape)
                    .background(Color(0x11FFFFFF)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "↑",
                    color = Color.White,
                    modifier = Modifier.rotate(state.targetBearingDeg),
                    style = MaterialTheme.typography.displayLarge
                )
            }
            Text("Dirección estimada", color = Color.White, fontWeight = FontWeight.Bold)
            Text(
                "${state.targetDistanceMeters.format(1)} m aprox.",
                color = Color(0xFF7DE1C3),
                style = MaterialTheme.typography.headlineSmall
            )
            Text("Confianza ${(state.confidence * 100).toInt()}%", color = Color(0xFF9CB0D2))
        }
    }
}

@Composable
private fun speedColor(speed: Float): Color = when {
    speed < 18f -> Color(0xFFE2B93B)
    speed > 60f -> Color(0xFFFF8A80)
    else -> Color(0xFF7DE1C3)
}

private fun Double.format(decimals: Int): String = String.format("%.${decimals}f", this)
