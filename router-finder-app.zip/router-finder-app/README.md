# Router Finder

Proyecto Android en Kotlin + Jetpack Compose para localizar físicamente un router o punto de acceso Wi‑Fi usando escaneo de redes, filtrado RSSI y sensores del teléfono.

## Qué incluye

- Escaneo de redes Wi‑Fi visibles
- Selección por BSSID
- Fase de calibración quieto
- Fase de caminar por pasos detectados con sensores
- Fase de giro 360° con progreso y velocidad en tiempo real
- Filtro de Kalman para suavizar RSSI
- Estimación básica de bearing y distancia aproximada
- UI minimalista, moderna y visual

## Qué falta pulir

- Afinado fino del algoritmo de pasos y bearing
- Gestión más completa de permisos por versión Android
- Foreground service / reintentos de escaneo según throttling
- Exportación de logs y telemetría de calibración
- Build firmado release

## Cómo compilar

1. Abre la carpeta en Android Studio.
2. Deja que sincronice Gradle e instale dependencias.
3. Compila con `Build > Build APK(s)`.
4. Instala la APK generada en `app/build/outputs/apk/debug/`.

## Nota

En este entorno no hay Android SDK ni acceso a tu repositorio remoto, así que no se pudo generar ni subir una APK final desde aquí.
